from flask import Flask, render_template, request, redirect
import string
import random
from models import db, URL   # import db and model together

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///urls.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database with app
db.init_app(app)

# Function to generate random short URL
def generate_short_url(num_chars=6):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(num_chars))

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        original_url = request.form['url']
        short_url = generate_short_url()

        # Save to database
        new_url = URL(original_url=original_url, short_url=short_url)
        db.session.add(new_url)
        db.session.commit()

        return render_template('home.html', short_url=short_url)
    return render_template('home.html')

@app.route('/history')
def history():
    urls = URL.query.all()
    return render_template('history.html', urls=urls)

@app.route('/<short_url>')
def redirect_url(short_url):
    url_entry = URL.query.filter_by(short_url=short_url).first()
    if url_entry:
        return redirect(url_entry.original_url)
    return "Invalid URL!"

if __name__ == '__main__':
    # Create tables before running
    with app.app_context():
        db.create_all()
    app.run(debug=True)